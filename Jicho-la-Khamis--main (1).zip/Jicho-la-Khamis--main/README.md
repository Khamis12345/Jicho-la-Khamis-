# Jicho-la-Khamis-
Al app for predicting hidden ball
